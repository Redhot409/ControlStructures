// Geometry

#include <iostream>
using namespace std;

#define FIVE_STAR_ROWS
#define ONE_TO_FIVE_STAR_ROWS_PART_1
#define FIVE_TO_ONE_STAR_ROWS_PART_1
#define FIVE_TO_ONE_STAR_ROWS_PART_2
#define ONE_TO_FIVE_STAR_ROWS_PART_2
#define RHOMB



void main()
{
	setlocale(LC_ALL, "");

	// FIVE Star rows

	int i, j;

#ifdef FIVE_STAR_ROWS 	
	for (i = 1; i <= 5; i++)
	{
		for (j = 1; j <= 5; j++)
		{
			if (j == 5)
			{
				cout << "*" << endl;
			}
			else cout << "*";
		}
	}
#endif

	// ONE to FIVE Star rows

#ifdef ONE_TO_FIVE_STAR_ROWS_PART_1
	for (i = 1; i <= 5; i++)
	{
		for (j = 1; j <=5; j++)
		{			
			if (j < i)
			{
				cout << "*";
			}
			else if (j == i)
			{
				cout <<"*"<<endl;
			}
		}	
	}
#endif

	//FIVE to ONE Star rows part_1

#ifdef FIVE_TO_ONE_STAR_ROWS_PART_1

	for (i = 1; i <= 5; i++)
	{
		for (j = 5; j >= 1; j--)
		{
			
			if (j > i)
			{
				cout << "*";	
			}
			else if (j == i)
			{
				cout << "*" << endl;
			}
		}
	}
#endif

	//FIVE to ONE Star rows part_2

#ifdef FIVE_TO_ONE_STAR_ROWS_PART_2

	for (i = 1; i <= 5; i++)
	{
		for (j = 1; j <= 5; j++)
		 {
			if (j >= i)
			{
				cout << "*";
			}
			else if (j < i)
			{
				cout << " ";
			}
			if (j == 5)
			{
				cout << endl;
			}
		 }
	}
#endif

	//ONE to FIVE Star rows part_2

#ifdef ONE_TO_FIVE_STAR_ROWS_PART_2
	for (i = 5; i >= 1; i--)
	{
		for (j = 1; j <= 5; j++)
		{
			if (j < i)
			{
				cout << " ";
			}
			else if (j > i)
			{
				cout << "*";
			}
			if (j == 5)
			{
				cout << "*" << endl;
			}
		}
	}
#endif

	// Rhomb

#ifdef RHOMB
	for (i = 1; i <= 10; i++)
	{
		if (i <= 5)
		{
			for (j = 1; j <= 5; j++)
			{
				if (j == 6 - i)
				{
					cout << "/";
				}
				else if (j != 6 - i)
				{
					cout << " ";
				}
			}
			for (j = 6; j <= 10; j++)
			{
				if (j == i + 5)
				{
					cout << "\\";
				}
				else if (j != i +5)
				{
					cout << " ";
				}
				if (j == 10)
				{
					cout << endl;
				}
			}
			
		}
		if (i > 5)
		{
			for (j = 1; j <= 5; j++)
			{
				if (j == i - 5)
				{
					cout << "\\";
				}
				else if (j != i - 5)
				{
					cout << " ";
				}
			}
			for (j = 6; j <= 10; j++)
			{
				if (j == 16 - i)
				{
					cout << "/";
				}
				else if (j != 16 - i)
				{
					cout << " ";
				}
				if (j == 10)
				{
					cout << endl;
				}
			}

		}
	}
#endif


	// plus-minus


	for (i = 1; i <= 5; i++)
	{
		for (j = 1; j <= 5; j++)
		{
			if (j == i) cout << " + ";
			else if (j == 6 - i) cout << " + ";
		 		// �� ���� ��������� 4 �����... �������� ��������			
			
			else cout << " - ";
			if (j == 5) cout << " " << "\n" << endl;
		}

	}

}